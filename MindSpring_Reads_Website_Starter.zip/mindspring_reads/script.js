/* MindSpring Reads front-end starter.
   Real production payments and protected content must be implemented server-side.
   Replace the sample books below with your own original writings and cover images. */
const AUTHOR_EMAIL = "mosesmdhami@gmail.com";
const MPESA_NUMBER = "0792470754";
const books = [
  {id:"mindset-reset",title:"The Mindset Reset",category:"Mindset",price:150,description:"A gentle, practical guide to noticing unhelpful thought patterns and choosing a more useful response.",coverTitle:"THE MINDSET RESET",color:"#315b49",ink:"#f4e6c5",label:"A PRACTICAL GUIDE",length:"18-minute read",sample:"Start by noticing the story you repeat to yourself. You do not have to believe every thought simply because it arrives. Write down one thought that limits you, then ask: what evidence supports it, what evidence challenges it, and what is a more balanced way to see this situation?"},
  {id:"habits-that-hold",title:"Habits That Hold",category:"Habits",price:200,description:"Build small routines that are realistic enough to repeat and meaningful enough to keep.",coverTitle:"HABITS THAT HOLD",color:"#e5cfa1",ink:"#294b3b",label:"SMALL STEPS DAILY",length:"24-minute read",sample:"Make the habit so small that starting feels almost too easy. Put your book beside your pillow, prepare your study space before bed, or take a five-minute walk after lunch. Repetition creates a path; consistency matters more than a perfect first attempt."},
  {id:"quiet-confidence",title:"Quiet Confidence",category:"Confidence",price:180,description:"Exercises for speaking up, setting boundaries and trusting yourself without pretending to be fearless.",coverTitle:"QUIET CONFIDENCE",color:"#b87960",ink:"#fff0d8",label:"TRUST YOURSELF",length:"20-minute read",sample:"Confidence is not the absence of nerves. It is the decision to take a useful step while nerves are present. Before a difficult conversation, write down the one thing you need to communicate clearly. You do not need to control every reaction to express yourself respectfully."},
  {id:"money-mindset",title:"A Healthier Money Mindset",category:"Money",price:250,description:"Reflect on spending habits, personal goals and simple ways to make more intentional financial choices.",coverTitle:"MONEY & MINDSET",color:"#344b65",ink:"#f5e4bd",label:"INTENTIONAL LIVING",length:"26-minute read",sample:"Begin with awareness, not judgement. Track your spending for seven days and mark each purchase as necessary, meaningful, or automatic. The goal is not to feel guilty; it is to understand where your money goes so your choices can better reflect your priorities."},
  {id:"start-again",title:"The Courage to Start Again",category:"Mindset",price:150,description:"A compassionate workbook for rebuilding momentum after disappointment, delay or a difficult season.",coverTitle:"THE COURAGE TO BEGIN",color:"#8b7759",ink:"#fff3d8",label:"BEGIN WHERE YOU ARE",length:"16-minute read",sample:"A setback can interrupt your plan without cancelling your future. Choose one small thing you can complete today. Let it be proof that movement is still possible, even when the full path is not yet clear."},
  {id:"focus-in-a-noisy-world",title:"Focus in a Noisy World",category:"Habits",price:220,description:"Simple reflection prompts to protect your attention and make space for the work that matters.",coverTitle:"FOCUS IN A NOISY WORLD",color:"#d7d9c7",ink:"#315542",label:"MAKE SPACE TO THINK",length:"22-minute read",sample:"Choose one task for the next 20 minutes. Silence notifications, move unrelated tabs out of sight and keep a note nearby for distracting thoughts. When the timer ends, decide whether to continue or take a short break. Protecting attention is a skill you can practise."}
];
let activeFilter="All", query="", toastTimer;
const bookGrid=document.getElementById("bookGrid");
const money=n=>new Intl.NumberFormat("en-KE",{style:"currency",currency:"KES",maximumFractionDigits:0}).format(n);
function showToast(message){const el=document.getElementById("toast");el.textContent=message;el.classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove("show"),3400)}
function renderBooks(){
 const filtered=books.filter(b=>(activeFilter==="All"||b.category===activeFilter)&&(`${b.title} ${b.category} ${b.description}`).toLowerCase().includes(query.toLowerCase()));
 bookGrid.innerHTML=filtered.length?filtered.map((b,i)=>`<article class="book-card"><div class="cover" style="background:${b.color};color:${b.ink}"><span class="cover-number">MSR / 0${i+1}</span><span class="cover-title">${b.coverTitle}</span><small>${b.label}</small></div><div class="card-content"><span class="tag">${b.category} · ${b.length}</span><h3>${b.title}</h3><p>${b.description}</p><div class="card-bottom"><span class="price">${money(b.price)}</span><button data-view="${b.id}">View writing ↗</button></div></div></article>`).join(""):'<div class="empty-state">No writings match that search. Try another word or topic.</div>';
 bookGrid.querySelectorAll("[data-view]").forEach(btn=>btn.addEventListener("click",()=>openBook(btn.dataset.view)));
}
function openDialog(id){const d=document.getElementById(id);if(d.showModal)d.showModal();else d.setAttribute("open","")}
function closeDialog(id){const d=document.getElementById(id);if(d.close)d.close();else d.removeAttribute("open")}
function openBook(id){
 const b=books.find(x=>x.id===id);if(!b)return;
 document.getElementById("bookDialogContent").innerHTML=`<span class="eyebrow">${b.category} · ${b.length}</span><h2>${b.title}</h2><div class="modal-cover" style="background:${b.color};color:${b.ink}"><span>${b.coverTitle}</span></div><p>${b.description}</p><div class="locked-content"><strong>What you'll take away</strong><p>Reflection prompts, practical steps and a short exercise you can apply in everyday life.</p><strong>Preview</strong><p>${b.sample.slice(0,155)}…</p></div><p><b>Price: ${money(b.price)}</b></p><button class="button primary" id="buyThisBook">Continue to payment <span>↗</span></button><p class="form-help">This is a website prototype. Payment is not collected here.</p>`;
 document.getElementById("buyThisBook").addEventListener("click",()=>{closeDialog("bookDialog");openPayment(b)});openDialog("bookDialog");
}
let selectedBook=null;
function openPayment(b){
 selectedBook=b;
 document.getElementById("paymentDialogContent").innerHTML=`<span class="eyebrow">CHECKOUT</span><h2>Get “${b.title}”</h2><p>Amount due</p><div class="payment-number">${money(b.price)}</div><p>For a manual payment workflow, send the exact amount to this M-Pesa number:</p><div class="payment-number">${MPESA_NUMBER}</div><ol class="steps-list"><li>Open M-Pesa on your phone.</li><li>Send <b>${money(b.price)}</b> to the number above.</li><li>Keep your M-Pesa confirmation message.</li><li>Contact the author with your receipt and the book title.</li></ol><label for="buyerEmail">Your email address (for follow-up)</label><input id="buyerEmail" type="email" placeholder="you@example.com" autocomplete="email"><button class="button primary" id="emailPaymentProof">Email payment details <span>↗</span></button><p class="form-help">No payment will be verified or access unlocked by this demo. Never enter your M-Pesa PIN on a website.</p>`;
 document.getElementById("emailPaymentProof").addEventListener("click",()=>{
  const email=document.getElementById("buyerEmail").value.trim();
  if(!email||!email.includes("@")){showToast("Please enter a valid email address.");return}
  const subject=encodeURIComponent("Payment enquiry: "+b.title);
  const body=encodeURIComponent(`Hello,\n\nI would like to purchase "${b.title}" for ${money(b.price)}.\nMy email: ${email}\nM-Pesa recipient: ${MPESA_NUMBER}\n\nI will attach or share my M-Pesa confirmation details for verification.\n\nThank you.`);
  window.location.href=`mailto:${AUTHOR_EMAIL}?subject=${subject}&body=${body}`;
  showToast("Your email app should open with a payment enquiry.");
 });
 openDialog("paymentDialog");
}
function updateLibrary(){
 const content=document.getElementById("libraryDialogContent");
 content.innerHTML=`<span class="eyebrow">YOUR READING SPACE</span><h2>My library</h2><p>Your purchased writings will appear here after the real payment system verifies them.</p><div class="locked-content"><strong>Not connected yet</strong><p>This prototype cannot remember purchases between devices or verify payments. A production version needs reader accounts, a database and secure M-Pesa callbacks.</p></div><button class="button primary" id="libraryExplore">Explore writings <span>↗</span></button>`;
 document.getElementById("libraryExplore").addEventListener("click",()=>{closeDialog("libraryDialog");document.getElementById("library").scrollIntoView({behavior:"smooth"})});
 document.getElementById("libraryCount").textContent="0";
}
document.querySelectorAll(".filter").forEach(btn=>btn.addEventListener("click",()=>{activeFilter=btn.dataset.filter;document.querySelectorAll(".filter").forEach(x=>x.classList.toggle("active",x===btn));renderBooks()}));
document.getElementById("searchInput").addEventListener("input",e=>{query=e.target.value;renderBooks()});
document.getElementById("myLibraryBtn").addEventListener("click",()=>{updateLibrary();openDialog("libraryDialog")});
document.querySelectorAll("[data-close]").forEach(btn=>btn.addEventListener("click",()=>btn.closest("dialog").close()));
document.querySelectorAll("dialog").forEach(d=>d.addEventListener("click",e=>{if(e.target===d)d.close()}));
document.getElementById("menuToggle").addEventListener("click",()=>{const nav=document.getElementById("mainNav"),btn=document.getElementById("menuToggle");nav.classList.toggle("open");btn.setAttribute("aria-expanded",nav.classList.contains("open")?"true":"false")});
document.querySelectorAll("#mainNav a").forEach(a=>a.addEventListener("click",()=>document.getElementById("mainNav").classList.remove("open")));
document.getElementById("contactForm").addEventListener("submit",e=>{e.preventDefault();const f=new FormData(e.currentTarget);const subject=encodeURIComponent("Message from MindSpring Reads website");const body=encodeURIComponent(`Name: ${f.get("name")}\nEmail: ${f.get("email")}\n\n${f.get("message")}`);window.location.href=`mailto:${AUTHOR_EMAIL}?subject=${subject}&body=${body}`;showToast("Your email app should open with the message ready.")});
document.getElementById("year").textContent=new Date().getFullYear();
renderBooks();updateLibrary();
